#sort rule
def sort_rule(alist):
    return alist[1]

#cost of wishlist
def cost(budget, products, wishlisted):
    
    sum = 0
    for i in wishlisted:
        sum = products[i[0]] * i[1]
        
    if sum > budget:
        return True
    else:
        False
        
#budgeting
def budgeting(budget, products, wishlist):
    
    w = sorted(wishlist.items(), key=sort_rule, reverse=True)      
    
    wishlisted = []
    
    for i in w:
        wishlisted.append([i[0], i[1]])
    
    value = 0
    for i in wishlisted:
        if value + products[i[0]] <= budget:
            value += products[i[0]]
            continue
        else:
            i[1] -= 1
            if i[1] == 0:
                wishlisted.remove([i[0], i[1]])
   
    return wishlisted








print(budgeting(1000, {'ps4': 350, 'smartphone': 400, 'jacket': 40,
'pc': 600, 'glasses': 75}, {'ps4': 1, 'smartphone': 1, 'pc': 1}))
 
    
print(budgeting(1500, {'xbox': 250, 'smartphone': 500, 'jeans': 50,
'pc': 600, 'glasses': 100}, {'glasses': 3, 'jeans': 2, 'pc': 1,
'xbox':1}))
    
print(budgeting(750, {'nintendo': 100, 'mouse': 20, 'hoodie': 45, 'backpack': 30, 'tv': 300}, {'nintendo': 1, 'mouse': 1, 'hoodie': 4, 'tv': 2}))



    