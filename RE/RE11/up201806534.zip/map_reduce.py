
from functools import reduce

def map_reduce(n1, n2):
    l = [i**2 for i in range(n1, n2, 1) if i%2==1]
#    return sum(l) if sum(l) > 50 else reduce((lambda x, y: x * y), l)
    return reduce((lambda x, y: x * y), l) if reduce((lambda x, y: x * y), l) < 50 else sum(l)
